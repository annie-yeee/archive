# select

*부서에 대한 목록을 조회

select *        // 컬럼절

from dept // from절

*부서에 대한 부서이름 목록을 조회

select dname from dept; // 절 단위로 끊어서 쳐도 괜찮

quiz ) 사원테이블에서 사원번호, 사원이름, 급여, 부서번호를 출력

![image.png](image.png)

![image.png](image%201.png)

⇒ as 는 별칭!

![image.png](image%202.png)

⇒ 별칭에 띄어쓰기 써주고 싶을 때는 단일 따음표 사용 (’  ‘)

⇒ as 안쓰고 ‘ ‘ 써도 칭으로 인식

![image.png](image%203.png)

계산도 가능!

- 산술연산자
- 비교연산자 ( 논리연산자 )
    - 1 : true / 0 : false

quiz ) 연봉 : 급여 * 12 + comm

⇒ 사원테이블 사원번호, 사원이름, 연봉    출력

![image.png](image%204.png)

select

from

where 조건

비교 / 논리

비교

=  !=

>< ≥ ≤

사원테이블에서 10번 부서에 대한 사원번호, 사원급여, 부서번호 출력

![image.png](image%205.png)

급여가 1000 이하인 사원에 대한 사원번호, 사원이름, 사원급여, 부서번호 출력

where sal ≤ 1000

사원 이름이 king 인 사원에 대한 사원번호, 사원이름, 사원급여, 부서번호 출력

select empno, ename, sal, deptno

from emp

where ename = ‘king’;

/// 문자는 ‘ ‘ // 대소문자 구분 x

입사일자가 2011년 12월 3일인 사원에 대한 사원번호, 사원이름, 입사일 출력

![image.png](image%206.png)

논리 : and, or

<범위형>

급여가 1000 이상 2000 이하인 사원에 대한 정보를 출력

1000 <= sal <= 2000 (X)

=⇒   1000 <= sal and sal <= 2000

1. 

select empno, ename, sal

from emp

where 1000 <= sal and sal <= 2000

1. 

select empno, ename, sal

from emp

where sal between 1000 and 2000;

// 숫자 순서를 바꾸면 나오지 않음 → 작은 수부터 차례대로

<목록형>

직책이 ‘clerk’ 이거나 ‘salesman’ 인 사원에 대한 사원번호, 사원이름, 직책, 부서번호를 출력

![image.png](image%207.png)

1.

select empno, ename, job, deptno
from emp
where job = 'clerk' or job = 'salesman';

2.

select empno, ename, job, deptno

from emp

where job in ( ‘clerk’, ‘salesman’ );

10 부서나 20 부서에 해당하는 사원에 대한 사원번호, 사원이름, 직책, 부서번호를 출력

where deptno in ( 10, 20 );

![image.png](image%208.png)

![image.png](image%209.png)

null * 산수 ⇒ null

보너스를 받는 사원에 대한 사원이름, 연봉을 출력

select empno, sal * 12 + comm

from emp

where comm is not null;

<부분 문자열 검색>

~ 시작

~ 끝

~ 을 포함하는

like

_    : 1글자

‘_문’ : 글자수가 2글자 인데, 뒷글자가 문인것

‘문_’

%  : 0개 이상의 여러 글자

‘%문’ ; 글자수는 상관 없고, 뒷글자가 문으로 끝나는 글자

‘문%’

‘%문%’ : 중간에 문 글자가 있는 // % 자리에 비어있어도 포함

사원이름이 ‘a’로 시작하는 사원에 대한 정보를 출력

select empno, ename from emp where ename like ‘a%’;

사원 이름이 ‘en’으로 끝나는 사원에 대한 정보를 출력

select empno, ename from emp where ename like ‘%en’;

입사 년도가 2011년인 사원의 정보

select empno, ename, hiredate

from emp

where hiredate like ‘2011%’;

입사월이 2월인 사원의 정보

select empno, ename, hiredate

from emp

where hiredate like ‘%02-%’;

사원이름이 네글자인 사원에 대한 정보 출력

where ename like ‘____’;

limit

limit 3 == limit 0, 3 ⇒ 위에서 3개

limit 2, 3 =⇒ 위에 (두+1)세번째부터 3개

order by  컬럼명; ⇒ 순서대로 ( 오름차순 )

order by 컬럼명 asc; ⇒ (오름차순)

order by 명 desc; ⇒ (내림차순) z → a

![image.png](image%2010.png)

order by 뒤에 여러개를 , 를 통해 나열하면 동률인 경우 차례대로 정렬함

distinct : 중복제거

![image.png](image%2011.png)

직책의 목록을 출력

select abs(); ⇒ 절댓값

floor(); ⇒ 내림

ceil(); ⇒ 올림

round(); ⇒ 반올림

power( a, b ); / pow( a, b ); ⇒ a의 b승 ( 거듭제곱 )

ascii () ⇒ 아스키코드

length( ‘ ‘ ) ⇒ 길이 // 한글은 char_length( ’ ’ ); 이용해야함

![image.png](image%2012.png)

사원이름이 네글자인 사원

![image.png](image%2013.png)

<문자열 결합>

select concat( , );

![image.png](image%2014.png)

![image.png](image%2015.png)

select concat( ename, ‘ 님의 담당업무는 ‘, job, ’ 입니다.’) ‘직책 내용’

from emp

where deptno = 10;

![image.png](image%2016.png)

select concat( ename, ‘ 님의 연봉은 ‘, sal * 12, ‘원 입니다.’) ‘연봉 내용’

from emp

where deptno = 10;

select instr( ‘이 문장에서’, ‘이것은’ ); 어디서 시작하는지 위치 찾기 ⇒ 없을 시에는 0 값 반환

![image.png](image%2017.png)

![image.png](image%2018.png)

![image.png](image%2019.png)

select left( ename, 3 ) from emp where deptno = 30;

사원이름 s로 시작하는 사원에 대한 사원번호, 사원이름, 사원급여 출력 like 이외의 방법

select empno, ename,left( ename, 1 ) from emp where left( ename, 1) = 's';

replace : 첫번째 에서 두번째를 세번째로 바꿈

select replace ( 'MySQL database study', 'study', '스터디' );

insert

![image.png](image%2020.png)

lower(); / upper(); ⇒ 대문자/소문자 로!

reverse ⇒ 반대로

![image.png](image%2021.png)

trim( ‘  ‘ ) ⇒ 앞 뒤 공백 제거

![image.png](image%2022.png)

lpad( , , ); / rpad( , , );  ⇒ 공백 채우기

![image.png](image%2023.png)

select now(), sysdate(), current_timestamp(); // cur

![image.png](image%2024.png)

![image.png](image%2025.png)

![image.png](d62c3873-2a23-495d-90f7-3835160b75e3.png)

![image.png](image%2026.png)

select unix_timestamp(); ⇒ 초단위 출력

![image.png](image%2027.png)

![image.png](image%2028.png)

![image.png](image%2029.png)

now() + 1 ⇒ 1초 더하고 형태가 다르게 나옴

![image.png](image%2030.png)

![image.png](image%2031.png)

select datediff( ‘2025-05-17’, ‘2025-05-01’ ) ⇒ 16

⇒ 몇일이 차이나는지?

사원이름, 입사일로 경과된 날 수를 출력

![image.png](image%2032.png)

 select ename, datediff( hiredate, now() ) from emp; 도 가능

삼항연산자

if( 조건, ‘참’, ‘거짓’ );

1500< 급여 < 2500 ⇒ 적당

기타 ⇒ 부적당

![image.png](image%2033.png)

DML - Select 데이터 조회

*  대소문자 구분

*  ;       ⇒ 절 단위로 보기좋게 나누어 코딩

select *, 컬럼명, 함수, distinct, 연산자   ⇒      컬럼절

from 테이블명                                              ⇒      from절

where 비교, 논리, like                                 ⇒      where절, 조건절

order by 컬럼                                               ⇒      정렬

*

함수

![image.png](image%2034.png)

외부에 저장해서 불러오기

⇒ 저장할 때 노트 파일 위치랑 파일명.sql 로 한 뒤 ANSI 로 저장하기

source c:\MySQL\ex01.sql

![image.png](image%2035.png)

if

switch .. case .. default ..

⇒ case when .. then .. else .. end

![image.png](image%2036.png)

![image.png](image%2037.png)

⇒ ‘case 문’으로 별칭

select case
when 1 > 0 then 'true'
else 'false'
end;

==⇒ true

한글 표기

clerk     ⇒      사원

analyst    ⇒    조사

manager      ⇒   관리

president     ⇒    대표

salesman      ⇒    영업

![image.png](image%2038.png)

![image.png](image%2039.png)

부서별 급여 인상분

10 → 10%        * 1.1

10 → 20%

30 → x

사원번호, 사원이름, 현재급여, 인상급여

![image.png](image%2040.png)

직책별 급여 인상분

![image.png](image%2041.png)

![image.png](image%2042.png)

암호화

가역적               평문 → 암호 → 평문

비가역적           평문 → 암호 ( * )

mysql> select md5( '123456' );    ⇒ md5 암호화 알고리즘
+----------------------------------+
| md5( '123456' )                  |
+----------------------------------+
| e10adc3949ba59abbe56e057f20f883e |
+----------------------------------+
1 row in set (0.00 sec)

![image.png](image%2043.png)

AES_DECRYPT() / AES_ENCRYPT() 는 가역적 

1개 입력 → 1개 결과   :   단일행 함수

여러개 입력 → 1개의 결과   :   집합 함수 ( 통계 함수 )

최대/최소      max / min

개수                count

합계                sum

평균                avg

표준편차/분산

![image.png](image%2044.png)

![image.png](image%2045.png)

⇒ count ( comm ) 은 null 값을 빼고 카운트 한다.

![image.png](image%2046.png)

![image.png](image%2047.png)

그룹화

![image.png](image%2048.png)

직책별 급여의 합계를 출력

![image.png](image%2049.png)

부서별, 직업별 최고 금액 + 순서 정렬

![image.png](image%2050.png)

직책별, 부서별 급여 합계 [ 조건 : 급여합계 2000 이상만 출력 ]

![image.png](image%2051.png)

⇒ group by 의 조건절은 having 절로

![image.png](image%2052.png)

⇒ where 은 개인 조건 ⇒ 먼저 sal 이 1000이상인 것만 걸러주고 그룹화

쿼리 - 쿼리 ( 서브쿼리 )

‘SCOTT’ 사원의 급여보다 큰 급여를 받는 사원에 대한 정보 출력

1. SCOTT 사원의 급여
    
    select sal
    
    from emp
    
    where ename = ‘scott’;
    
2. 이 보다 큰 급여를 받는 사원
    
    select ename, sal
    
    from emp
    
    where ssal ≥ x ;
    

⇒

select ename, sal

from emp

where sal ≥ ( select sal from emp where ename = ‘scott’ );

![image.png](image%2053.png)

1. 단일행 서브쿼리
    1. 서브쿼리에 한 개의 데이터만 리턴
    2. 비교연산자
    3. 예제) 최고 급여를 받는 사원 정보 출력
        1. 최고 급여 < 서브 쿼리 >
            
            x = select max ( sal ) from emp;
            
        2. 그 급여를 받는 사원 정보
            
            select empno, ename, sal from emp where sal = x
            
            ![image.png](image%2054.png)
            
    4. ‘WARD’ 라는 사원과 급여가 같은 사원 정보 출력
        1. ‘WARD’라는 사원 급여
            
            x = select sal from emp where ename = ‘ward’
            
        2. 같은 급여를  받는 사원
            
            select empno, ename, sal from emp where sal = x
            
            ![image.png](image%2055.png)
            
    5. 20번 부서에서 최고 급여를 받는 사원보다 많은 급여를 받는 사원 정보 출력
        
        select empno, ename, sal
        
        from emp
        
        where sal > ( select max( sal ) from emp where deptno = 20 );
        
2. 복수행 서브쿼리
    1. 서브쿼리에 여러 개의 데이터 리턴
    2. all, any …
    3. 예제) 부서별 최고 급여를 받는 사원에 대한 정보 출력
        
        select empno, ename, sal
        
        from emp
        
        where sal in ( select max( sal ) from emp group by deptno );
        
        ![image.png](image%2056.png)
        
    4. 예제 ) 20번 부서의 사원이 속한 업무와 같은 업무를 하는 사원들에 대한 정보
        
        select empno, ename, job
        
        from emp
        
        where job in ( select distinct job from emp where deptno = 20 );
        
        ![image.png](image%2057.png)
        

![image.png](image%2058.png)

직책이 manager 인 사람들의 급여 전체보다 적은 사원들에 대한 정보 출력

select sal where job = ‘manager’;

![image.png](image%2059.png)

![image.png](image%2060.png)

각 부서의 평균 급여 전체보다 적은 사람들에 대한 정보 출력

### JOIN

![image.png](image%2061.png)

select * from emp cross join dept;

select * from dept cross join emp;

< equi-join > - 등호

![image.png](image%2062.png)

![image.png](image%2063.png)

⇒ 별칭 ( 컬럼명 보통 한글자로 )

![image.png](image%2064.png)

![image.png](image%2065.png)

1. ***where***
    
    select e.empno, e.ename, e.sal, e.deptno
    
    from dept d inner join emp e
    
    where d.deptno = e.deptno and e.deptno = 10;
    

1. ***on*** **: where을 자유롭게 쓰기 위해 사용**
    
    select e.empno, e.ename, e.sal, e.deptno
    
    from dept d inner join emp e
    
    on ( d.deptno = e.deptno )
    
    where e.deptno = 10;
    
2. ***using*** **: 컬럼명이 같은 경우**
    
    select e.empno, e.ename, e.sal, e.deptno
    
    from dept d inner join emp e
    
    using ( deptno )
    
    where e.deptno = 10;
    
3. ***inner join → join***
    
    select e.empno, e.ename, e.sal, e.deptno
    
    from dept d join emp e
    
    using ( deptno )
    
    where e.deptno = 10;
    

예제 1) 직책이 clerk인 사원에 대한 사원번호, 사원이름, 관리자, 부서번호, 부서이름, 부서위치 출력

select e.empno, e.ename, e.mgr, d.deptno, d.dname, d.loc

from emp e inner join dept d

using( deptno )

where e.job = ‘clerk’;

![image.png](image%2066.png)

예제 2) 입사년도가 2011년인 사원에 대한 사원번호, 사원이름, 입사일, 부서이름, 부서위치 출력

![image.png](image%2067.png)

< non equi join > - 부등호

select e.empno, e.ename, e.sal, s.grade

from emp e inner join salgrade s

1. where e.sal >= s.losal and e.sal <= s.hisal;
2. on ( e.sal >= s.losal and e.sal <= s.hisal );
3. on ( e.sal between s.losal and e.sal and s.hisal );

![- - : 주석](image%2068.png)

- - : 주석

사원에 대한 사원번호, 사원이름, 급여등급( 호봉 ), 기존급여, 인상급여를 출력

1 호봉 → 40% 인상

2 호봉 → 30% 인상

3 호봉 → 20% 인상

기타 → 인상없음

![다시 해보기](6db5748d-94b7-4893-98a6-f79c34446057.png)

다시 해보기

< 2개 이상의 테이블 >

![image.png](d952e87e-a3c1-401c-b60e-b32dcfdecd30.png)

join 끼리 / on 끼리 도 가능

select e.empno, e.ename, e.sal, d.dname, d.loc, s.grade
from emp e **inner join** dept d **inner join** salgrade s
**on** ( e.deptno = d.deptno **and** e.sal between s.losal and s.hisal );

![오류남 다시 해보기](image%2069.png)

오류남 다시 해보기

![오류 다시 보기!!](image%2070.png)

오류 다시 보기!!

![이것도 다시 12번 텍스트 ⇒ 해결 : 다시 보기](image%2071.png)

이것도 다시 12번 텍스트 ⇒ 해결 : 다시 보기

< self join > - 한 개의 테이블

ex1 ) 사원 - 관리자

![image.png](image%2072.png)

⇒ 관리자 없는 king 이 나타나지 않음!

![image.png](image%2073.png)

⇒ left outer join 이용하면 왼쪽 emp 는 모두 나타나야함!

ex2 ) 사원번호, 사원이름, 관리자 이름을 출력 ( 관리자가 없으면 ‘없음’ 으로 출력 )

![image.png](image%2074.png)